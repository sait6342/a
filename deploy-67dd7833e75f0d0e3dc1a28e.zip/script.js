function openBox() {
  const box = document.getElementById('box');
  const flower = document.getElementById('flower');
  box.classList.add('hidden');
  flower.classList.remove('hidden');
}

function handleNo() {
  const question = document.getElementById('question');
  const flowerFace = document.getElementById('flower-face');
  const noBtn = document.getElementById('no-btn');
  const yesBtn = document.getElementById('yes-btn');

  question.textContent = "Hah? Sombong banget sih! 😠";
  flowerFace.src = "https://via.placeholder.com/100x100/FF6666/FFFFFF?text=😠"; // Gambar marah
  flowerFace.style.transform = "rotate(10deg)"; // Animasi marah
  noBtn.style.display = "none"; // Sembunyikan tombol "Nggak ah!"
  yesBtn.textContent = "Iya deh, maap ya!!"; // Ubah teks tombol
}

function handleYes() {
  const question = document.getElementById('question');
  const flowerFace = document.getElementById('flower-face');
  const options = document.getElementById('options');

  question.textContent = "nah gitu dong, awokwok ";
  flowerFace.src = "https://via.placeholder.com/100x100/FFCCCB/000000?text=😊"; // Gambar bahagia
  flowerFace.style.transform = "rotate(0deg)"; // Kembali ke posisi normal
  options.style.display = "none"; // Sembunyikan tombol setelah menjawab "Iya"
}